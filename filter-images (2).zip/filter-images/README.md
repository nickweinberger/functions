<!--Documentation-->

Project designed to implement four image filters–blur, greyscale, reflect, sapia–onto jpegs.