## Documentation

Functions that output the reading level of an inputed text block, based on grade in U.S. school. Written in Python and C.